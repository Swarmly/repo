#!/bin/bash
echo 'HELLO FROM PROGRAM' | zenity --text-info 
